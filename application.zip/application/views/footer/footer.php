<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->
<script src="<?php echo base_url(); ?>assets/survey/js/jquery.min.js"> </script>
	<footer class="footer" style="background:#1A237E /*rgb(0, 78, 140);*/">
      <div class="container">
        <center><span class="text-muted" style="color:#fff !important;">© 2021 Netcom Africa Limited. All rights reserved. | Terms & Conditions</span></center>
      </div>
    </footer>
</body>
</html>